
export interface GaitMetrics {
  arm_swing_symmetry: "Low" | "Medium" | "High" | "Normal" | "Reduced" | "Asymmetrical" | string;
  shuffling_detected: "Minimal" | "Moderate" | "Significant" | "None" | string;
  posture_score: "Good" | "Fair" | "Poor" | string;
  step_consistency: "High" | "Medium" | "Low" | string;
}

export interface GaitAnalysisResult {
  risk_score: number;
  analysis_summary: string;
  gait_metrics: GaitMetrics;
}
