
import React from 'react';

interface ProgressBarProps {
  value: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ value }) => {
  const normalizedValue = Math.max(0, Math.min(100, value));

  const getColor = () => {
    if (normalizedValue <= 30) return 'bg-brand-success'; // Low risk
    if (normalizedValue <= 60) return 'bg-brand-warning'; // Moderate risk
    return 'bg-brand-danger'; // High risk
  };

  const getRiskLabel = () => {
    if (normalizedValue <= 30) return 'Low Risk';
    if (normalizedValue <= 60) return 'Moderate Risk';
    return 'High Risk';
  }

  return (
    <div>
        <div className="flex justify-between mb-1">
            <span className="text-base font-medium text-brand-text">Risk Score</span>
            <span className={`text-sm font-medium ${getColor().replace('bg-','text-')}`}>{getRiskLabel()}</span>
        </div>
        <div className="w-full bg-brand-secondary rounded-full h-4">
            <div
                className={`h-4 rounded-full transition-all duration-1000 ease-out ${getColor()}`}
                style={{ width: `${normalizedValue}%` }}
            ></div>
        </div>
         <div className="text-center mt-2 font-mono text-2xl font-bold text-brand-text">{normalizedValue} / 100</div>
    </div>
  );
};
