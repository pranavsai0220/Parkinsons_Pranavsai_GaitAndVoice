
import React, { useRef, useState } from 'react';
import { UploadIcon } from './icons';

interface VideoUploaderProps {
  onFileChange: (file: File | null) => void;
  previewUrl: string | null;
  disabled: boolean;
}

export const VideoUploader: React.FC<VideoUploaderProps> = ({ onFileChange, previewUrl, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (files: FileList | null) => {
    if (files && files.length > 0) {
      onFileChange(files[0]);
    } else {
      onFileChange(null);
    }
  };

  const onDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files);
    }
  };

  return (
    <div
      className={`relative border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors duration-300 ${isDragging ? 'border-brand-primary bg-sky-900/50' : 'border-brand-secondary hover:border-brand-primary'} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      onClick={() => !disabled && fileInputRef.current?.click()}
      onDragEnter={onDragEnter}
      onDragLeave={onDragLeave}
      onDragOver={onDragOver}
      onDrop={onDrop}
    >
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="video/mp4,video/quicktime,video/mov"
        onChange={(e) => handleFileSelect(e.target.files)}
        disabled={disabled}
      />
      {previewUrl ? (
        <div className="relative">
          <video src={previewUrl} controls className="max-h-60 mx-auto rounded-lg" />
          <p className="text-sm mt-2 text-brand-text-secondary">
            File selected. Click here or drag another file to replace.
          </p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center">
            <UploadIcon />
          <p className="mt-2 font-semibold text-brand-text">
            Drag & drop your video here
          </p>
          <p className="text-sm text-brand-text-secondary">or click to browse</p>
        </div>
      )}
    </div>
  );
};
