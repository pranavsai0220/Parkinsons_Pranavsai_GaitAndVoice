
import React from 'react';
import type { GaitAnalysisResult, GaitMetrics } from '../types';
import { ProgressBar } from './ProgressBar';

interface ResultsDisplayProps {
  result: GaitAnalysisResult;
}

const MetricCard: React.FC<{ label: string; value: string }> = ({ label, value }) => {
    const getBadgeColor = (val: string) => {
        const lowerVal = val.toLowerCase();
        if (['low', 'poor', 'asymmetrical', 'minimal', 'moderate', 'significant'].some(keyword => lowerVal.includes(keyword))) {
            return 'bg-amber-500/20 text-amber-300';
        }
        if (['normal', 'good', 'high', 'none'].some(keyword => lowerVal.includes(keyword))) {
            return 'bg-green-500/20 text-green-300';
        }
        return 'bg-sky-500/20 text-sky-300';
    };

    return (
        <div className="bg-brand-secondary p-4 rounded-lg flex flex-col justify-between">
            <p className="text-sm text-brand-text-secondary font-medium mb-2">{label}</p>
            <p className={`text-lg font-semibold px-2 py-1 rounded-md text-center self-start ${getBadgeColor(value)}`}>{value}</p>
        </div>
    )
};


export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result }) => {
  const { risk_score, analysis_summary, gait_metrics } = result;

  const metrics: { label: string; key: keyof GaitMetrics }[] = [
      { label: 'Arm Swing Symmetry', key: 'arm_swing_symmetry' },
      { label: 'Shuffling Detected', key: 'shuffling_detected' },
      { label: 'Posture Score', key: 'posture_score' },
      { label: 'Step Consistency', key: 'step_consistency' },
  ];

  return (
    <div className="bg-brand-background/50 border border-brand-secondary rounded-lg p-6 space-y-6 animate-fade-in">
      <div>
        <ProgressBar value={risk_score} />
      </div>

      <div>
        <h3 className="text-lg font-semibold text-brand-text mb-2">Analysis Summary</h3>
        <p className="text-brand-text-secondary italic">"{analysis_summary}"</p>
      </div>

      <div>
         <h3 className="text-lg font-semibold text-brand-text mb-3">Gait Metrics</h3>
         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {metrics.map(metric => (
                <MetricCard key={metric.key} label={metric.label} value={gait_metrics[metric.key]} />
            ))}
         </div>
      </div>
    </div>
  );
};
