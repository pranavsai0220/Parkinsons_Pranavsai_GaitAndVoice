
import { GoogleGenAI, Type } from "@google/genai";
import type { GaitAnalysisResult } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedData = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });

  return {
    inlineData: {
      mimeType: file.type,
      data: base64EncodedData,
    },
  };
};

const gaitAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    risk_score: {
      type: Type.INTEGER,
      description: "A numerical score from 0 to 100 representing the likelihood of Parkinsonian gait patterns. Higher scores indicate higher risk. 0-30 is low, 31-60 is moderate, 61+ is high.",
    },
    analysis_summary: {
      type: Type.STRING,
      description: "A concise, one to two-sentence summary of the key findings from the gait analysis, framed in a neutral, clinical tone.",
    },
    gait_metrics: {
      type: Type.OBJECT,
      properties: {
        arm_swing_symmetry: {
          type: Type.STRING,
          description: "Assessment of arm swing symmetry. Values: 'Normal', 'Slightly Reduced', 'Reduced', 'Asymmetrical'.",
        },
        shuffling_detected: {
          type: Type.STRING,
          description: "Assessment of shuffling gait, characterized by short, sliding steps. Values: 'None', 'Minimal', 'Moderate', 'Significant'.",
        },
        posture_score: {
          type: Type.STRING,
          description: "Assessment of posture during walking. Values: 'Good' (upright), 'Fair' (slight stoop), 'Poor' (stooped/rigid).",
        },
        step_consistency: {
          type: Type.STRING,
          description: "Assessment of step rhythm and consistency. Low consistency may indicate freezing or hesitation. Values: 'High', 'Medium', 'Low'.",
        },
      },
      required: ["arm_swing_symmetry", "shuffling_detected", "posture_score", "step_consistency"],
    },
  },
  required: ["risk_score", "analysis_summary", "gait_metrics"],
};

export const analyzeGait = async (videoFile: File): Promise<GaitAnalysisResult> => {
  console.log("Starting gait analysis for file:", videoFile.name);
  const videoPart = await fileToGenerativePart(videoFile);

  const prompt = `
    You are an expert AI system performing quantitative gait analysis to detect early signs of Parkinson's Disease.
    Your analysis MUST be objective, data-driven, and consistent with findings from established clinical research datasets (e.g., PhysioNet Gait in Parkinson's Disease, Kaggle's Gait in Parkinson's Disease).

    Analyze the provided video of a person walking. Your task is to identify and quantify subtle abnormalities in their gait based on the following key spatiotemporal markers:

    1.  **Quantitative Stride/Step Analysis:** Pay close attention to stride and step intervals. Assess the symmetry between the right and left sides. Asymmetry in stride/step time is a critical indicator. Note any significant variance.
    2.  **Arm Swing (Hypokinesia):** Quantify the amplitude and symmetry of arm movement. A classic early sign is reduced arm swing on one side.
    3.  **Stride Length & Shuffling:** Measure the step length relative to the subject's height (if discernible). Note any shuffling, where feet barely clear the ground.
    4.  **Posture & Rigidity:** Observe for postural instability, such as a stooped, forward-flexed trunk.
    5.  **Cadence & Freezing of Gait (FOG):** Note the rhythm of steps. Look for signs of hesitation or FOG, which manifests as low step consistency.

    Based on your rigorous, quantitative analysis, provide a risk assessment. Your output MUST be a valid JSON object that adheres to the provided schema. Do not include any additional text or markdown formatting like \`\`\`json.
    `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: [{ text: prompt }, videoPart] },
        config: {
            responseMimeType: "application/json",
            responseSchema: gaitAnalysisSchema,
        },
    });

    const jsonText = response.text.trim();
    console.log("Received raw JSON from API:", jsonText);
    
    // Sometimes the API might wrap the JSON in markdown, let's strip it.
    const cleanJsonText = jsonText.replace(/^```json\s*|```\s*$/g, '');

    const result = JSON.parse(cleanJsonText);
    console.log("Parsed analysis result:", result);
    return result as GaitAnalysisResult;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error && error.message.includes("400")) {
         throw new Error("The uploaded video format may not be supported for analysis by the model. Please try a different video or format (e.g., a standard MP4).");
    }
    throw new Error("Failed to analyze gait. The AI model could not process the request.");
  }
};