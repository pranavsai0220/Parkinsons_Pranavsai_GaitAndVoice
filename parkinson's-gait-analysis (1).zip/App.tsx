
import React, { useState, useCallback } from 'react';
import { Disclaimer } from './components/Disclaimer';
import { Header } from './components/Header';
import { ResultsDisplay } from './components/ResultsDisplay';
import { VideoUploader } from './components/VideoUploader';
import { analyzeGait } from './services/geminiService';
import type { GaitAnalysisResult } from './types';
import { SpinnerIcon } from './components/icons';

export default function App() {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<GaitAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);

  const handleFileChange = (file: File | null) => {
    setVideoFile(file);
    setAnalysisResult(null);
    setError(null);
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoPreviewUrl(url);
    } else {
      if (videoPreviewUrl) {
        URL.revokeObjectURL(videoPreviewUrl);
      }
      setVideoPreviewUrl(null);
    }
  };

  const handleAnalyzeClick = useCallback(async () => {
    if (!videoFile) {
      setError("Please select a video file first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const result = await analyzeGait(videoFile);
      setAnalysisResult(result);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unknown error occurred during analysis.");
    } finally {
      setIsLoading(false);
    }
  }, [videoFile]);

  return (
    <div className="min-h-screen bg-brand-background font-sans">
      <main className="container mx-auto px-4 py-8 md:py-12">
        <Header />
        <div className="max-w-3xl mx-auto mt-8">
          <Disclaimer />
          <div className="bg-brand-surface rounded-lg shadow-2xl p-6 md:p-8 mt-6">
            <div className="grid grid-cols-1 gap-8">
              <div>
                <h2 className="text-xl font-semibold text-brand-text mb-4">1. Upload Walking Video</h2>
                <p className="text-brand-text-secondary mb-4">
                  Upload a short video (5-10 seconds) of walking. Ensure the full body is visible. Supported formats: MP4, MOV.
                </p>
                <VideoUploader
                  onFileChange={handleFileChange}
                  previewUrl={videoPreviewUrl}
                  disabled={isLoading}
                />
              </div>

              <div className="flex flex-col items-center">
                 <button
                  onClick={handleAnalyzeClick}
                  disabled={!videoFile || isLoading}
                  className="w-full md:w-auto flex items-center justify-center gap-3 px-8 py-4 bg-brand-primary text-white font-bold rounded-lg shadow-lg hover:bg-sky-600 focus:outline-none focus:ring-4 focus:ring-sky-400 focus:ring-opacity-50 transition-all duration-300 disabled:bg-brand-secondary disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {isLoading ? (
                    <>
                      <SpinnerIcon />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Walking Pattern"
                  )}
                </button>
              </div>

              {error && (
                <div className="bg-red-900/50 border border-brand-danger text-brand-danger px-4 py-3 rounded-lg" role="alert">
                  <strong className="font-bold">Error: </strong>
                  <span className="block sm:inline">{error}</span>
                </div>
              )}

              {analysisResult && (
                <div>
                  <h2 className="text-xl font-semibold text-brand-text mb-4">2. Analysis Results</h2>
                  <ResultsDisplay result={analysisResult} />
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
