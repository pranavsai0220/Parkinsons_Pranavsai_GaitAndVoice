
export interface FeatureExtracts {
  pitch_variability: number;
  jitter: number;
  shimmer: number;
  speech_rate: number;
}

export interface AnalysisResult {
  risk_score: number; // Kept for Gemini's qualitative summary, but not primary display
  analysis_summary: string;
  feature_extracts: FeatureExtracts;
}

export interface ClassificationResult {
  prediction: 'Healthy' | 'Potential Indicators';
  confidence: number;
}

export interface FeatureChartData {
  name: string;
  userValue: number;
  typicalMin: number;
  typicalMax: number;
}

export interface NormalizationStats {
  [key: string]: {
    min: number;
    max: number;
  }
}
