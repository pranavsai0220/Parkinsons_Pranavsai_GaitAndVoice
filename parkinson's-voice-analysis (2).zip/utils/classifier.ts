
import type { FeatureExtracts, NormalizationStats } from '../types';

// The features from the dataset that we will use for comparison.
// We map our Gemini-extracted features to these dataset columns.
const featureMapping = {
    jitter: 'MDVP:Jitter(%)',
    shimmer: 'MDVP:Shimmer', // Note: dataset shimmer is decimal, our Gemini feature is %
};

// 1. Helper function to normalize a value between 0 and 1
const normalize = (value: number, min: number, max: number): number => {
    if (max === min) return 0;
    return (value - min) / (max - min);
};

// 2. Calculate Euclidean distance between two feature vectors
const calculateDistance = (a: FeatureExtracts, b: Record<string, any>, stats: NormalizationStats): number => {
    let sum = 0;

    // Jitter
    const normJitterA = normalize(a.jitter, stats.jitter.min, stats.jitter.max);
    const normJitterB = normalize(b[featureMapping.jitter], stats.jitter.min, stats.jitter.max);
    sum += Math.pow(normJitterA - normJitterB, 2);

    // Shimmer
    const normShimmerA = normalize(a.shimmer, stats.shimmer.min, stats.shimmer.max);
    // Convert dataset shimmer to % before normalizing
    const normShimmerB = normalize(b[featureMapping.shimmer] * 100, stats.shimmer.min, stats.shimmer.max);
    sum += Math.pow(normShimmerA - normShimmerB, 2);
    
    // Pitch Variability
    const pitchVarB = ((b['MDVP:Fhi(Hz)'] - b['MDVP:Flo(Hz)']) / b['MDVP:Fo(Hz)']) * 100;
    if (isFinite(pitchVarB)) {
        const normPitchA = normalize(a.pitch_variability, stats.pitch_variability.min, stats.pitch_variability.max);
        const normPitchB = normalize(pitchVarB, stats.pitch_variability.min, stats.pitch_variability.max);
        sum += Math.pow(normPitchA - normPitchB, 2);
    }

    return Math.sqrt(sum);
};

// 3. K-Nearest Neighbors classifier
export const classify = (
    features: FeatureExtracts,
    dataset: Record<string, any>[],
    stats: NormalizationStats,
    k: number
) => {
    const distances = dataset
        .map(point => ({
            dist: calculateDistance(features, point, stats),
            status: point.status,
        }))
        .filter(d => isFinite(d.dist)); // Filter out any NaN/Infinity distances

    distances.sort((a, b) => a.dist - b.dist);

    const neighbors = distances.slice(0, k);

    const votes: { [key: number]: number } = {};
    neighbors.forEach(n => {
        votes[n.status] = (votes[n.status] || 0) + 1;
    });

    const positiveVotes = votes[1] || 0;
    const negativeVotes = votes[0] || 0;

    let prediction: 'Healthy' | 'Potential Indicators';
    let confidence: number;
    
    if (positiveVotes > negativeVotes) {
        prediction = 'Potential Indicators';
        confidence = Math.round((positiveVotes / k) * 100);
    } else {
        prediction = 'Healthy';
        confidence = Math.round((negativeVotes / k) * 100);
    }

    // Edge case for a perfect tie, default to healthy
    if (positiveVotes === negativeVotes) {
        prediction = 'Healthy';
        confidence = 50;
    }

    return { prediction, confidence };
};
