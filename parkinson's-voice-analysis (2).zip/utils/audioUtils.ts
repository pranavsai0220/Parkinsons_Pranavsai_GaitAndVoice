
export const fileToBase64 = (file: File | Blob): Promise<{ base64String: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // result is in format "data:audio/wav;base64,...."
      const mimeType = result.split(':')[1].split(';')[0];
      const base64String = result.split(',')[1];
      resolve({ base64String, mimeType });
    };
    reader.onerror = (error) => reject(error);
  });
};
