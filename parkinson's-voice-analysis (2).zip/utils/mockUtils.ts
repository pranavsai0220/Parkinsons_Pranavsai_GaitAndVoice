
import type { AnalysisResult, FeatureExtracts } from '../types';

// Helper to generate a random number within a range
const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

// Function to create a mock analysis result from a dataset record
export const createMockResult = (record: Record<string, any>): AnalysisResult => {
  const status = Number(record.status);

  // 1. Map features directly from the dataset
  // We use parseFloat to ensure they are numbers. The dataset uses strings.
  const feature_extracts: FeatureExtracts = {
    jitter: parseFloat(record['MDVP:Jitter(%)']) || 0,
    shimmer: parseFloat(record['MDVP:Shimmer']) * 100 || 0, // Shimmer in dataset is decimal, we use percentage
    // Estimate pitch variability from frequency range
    pitch_variability: ((parseFloat(record['MDVP:Fhi(Hz)']) - parseFloat(record['MDVP:Flo(Hz)'])) / parseFloat(record['MDVP:Fo(Hz)'])) * 100 || 0,
    // Dataset does not have speech rate, so we simulate it based on status
    speech_rate: status === 1 ? randomInRange(100, 145) : randomInRange(150, 180),
  };
  
  // Clean up any NaN/Infinity values
  Object.keys(feature_extracts).forEach(key => {
      const k = key as keyof FeatureExtracts;
      if (!isFinite(feature_extracts[k])) {
          feature_extracts[k] = 0;
      }
      feature_extracts[k] = parseFloat(feature_extracts[k].toFixed(2));
  });


  // 2. Generate a plausible risk score and summary based on the ground truth 'status'
  let risk_score: number;
  let analysis_summary: string;

  if (status === 1) { // Parkinson's positive
    risk_score = Math.floor(randomInRange(65, 90));
    analysis_summary = "This sample from the research dataset shows significant deviations in vocal features. The elevated jitter and shimmer, combined with a compressed pitch range, are patterns strongly consistent with those seen in individuals with Parkinson's Disease.";
  } else { // Healthy control
    risk_score = Math.floor(randomInRange(10, 35));
    analysis_summary = "This healthy control sample from the research dataset displays vocal features within typical neurological ranges. Jitter and shimmer are low, and pitch variability is normal, indicating stable vocal control.";
  }

  return {
    risk_score,
    analysis_summary,
    feature_extracts,
  };
};
