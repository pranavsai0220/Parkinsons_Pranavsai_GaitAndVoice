
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Disclaimer } from './components/Disclaimer';
import { AudioInput } from './components/AudioInput';
import { ResultsDisplay } from './components/ResultsDisplay';
import { Spinner } from './components/Spinner';
import { analyzeVoice } from './services/geminiService';
import { classify } from './utils/classifier';
import { getFullDataset, getNormalizationStats } from './data/parkinsonsData';
import type { AnalysisResult, ClassificationResult } from './types';
import { fileToBase64 } from './utils/audioUtils';

const App: React.FC = () => {
  const [audioSource, setAudioSource] = useState<File | Blob | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [classificationResult, setClassificationResult] = useState<ClassificationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAudioReady = useCallback((source: File | Blob) => {
    setAudioSource(source);
    setAnalysisResult(null);
    setClassificationResult(null);
    setError(null);
  }, []);
  
  const resetApp = () => {
    setAudioSource(null);
    setAnalysisResult(null);
    setClassificationResult(null);
    setError(null);
    setIsLoading(false);
  };

  const handleAnalyze = async () => {
    if (!audioSource) {
      setError("Please provide an audio sample first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setClassificationResult(null);

    try {
      // Step 1: Use Gemini to extract features from raw audio
      const { base64String, mimeType } = await fileToBase64(audioSource);
      const geminiResult = await analyzeVoice(base64String, mimeType);
      setAnalysisResult(geminiResult);

      // Step 2: Use the extracted features to classify against the dataset
      const dataset = getFullDataset();
      const stats = getNormalizationStats();
      const knnResult = classify(geminiResult.feature_extracts, dataset, stats, 5); // Using K=5
      setClassificationResult(knnResult);

    } catch (err) {
      console.error("Analysis failed:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred during analysis. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-64">
          <Spinner />
          <p className="text-brand-blue mt-4 text-lg animate-pulse">Analyzing & classifying... this may take a moment.</p>
        </div>
      );
    }

    if (error) {
       return (
        <div className="text-center">
          <p className="text-brand-dark-red font-semibold mb-4">{error}</p>
          <button
            onClick={resetApp}
            className="bg-brand-orange text-white font-bold py-2 px-6 rounded-lg hover:bg-brand-dark-orange transition-colors"
          >
            Try Again
          </button>
        </div>
       );
    }
    
    if (analysisResult && classificationResult) {
        return <ResultsDisplay geminiResult={analysisResult} classificationResult={classificationResult} onReset={resetApp} />;
    }

    return <AudioInput onAudioReady={handleAudioReady} onAnalyze={handleAnalyze} audioSource={audioSource} />;
  }

  return (
    <div className="min-h-screen bg-brand-bg font-sans text-gray-800 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-8 flex flex-col items-center justify-center">
        <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 md:p-8 transition-all duration-500">
         {renderContent()}
        </div>
      </main>
      <Disclaimer />
    </div>
  );
};

export default App;
