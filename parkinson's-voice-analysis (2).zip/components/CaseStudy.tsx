
import React from 'react';
import { getCaseStudies } from '../data/parkinsonsData';
import { createMockResult } from '../utils/mockUtils';
import { ResultsDisplay } from './ResultsDisplay';
// FIX: Import ClassificationResult type
import type { ClassificationResult } from '../types';

interface CaseStudyProps {
  onBack: () => void;
}

export const CaseStudy: React.FC<CaseStudyProps> = ({ onBack }) => {
  const { healthy, parkinsons } = getCaseStudies();
  
  // FIX: Rename variables for clarity and create mock classification results
  const healthyGeminiResult = createMockResult(healthy);
  const parkinsonsGeminiResult = createMockResult(parkinsons);

  const healthyClassificationResult: ClassificationResult = {
    prediction: 'Healthy',
    confidence: 95, // Representative high confidence for a clear healthy case
  };

  const parkinsonsClassificationResult: ClassificationResult = {
    prediction: 'Potential Indicators',
    confidence: 88, // Representative high confidence for a clear parkinson's case
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-2xl font-bold text-brand-blue mb-2 text-center">Dataset Case Study</h2>
      <p className="text-center text-gray-500 text-sm mb-6">
        This is a simulated analysis using data from the UCI Machine Learning Repository's Parkinson's dataset.
        It shows how the app visualizes data for a healthy individual versus an individual with Parkinson's.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-green-200 bg-green-50 rounded-xl p-4">
            <h3 className="text-xl font-semibold text-center text-green-800 mb-4">Healthy Control Sample</h3>
            {/* FIX: Pass correct props to ResultsDisplay */}
            <ResultsDisplay 
              geminiResult={healthyGeminiResult} 
              classificationResult={healthyClassificationResult} 
              onReset={onBack} 
            />
        </div>
        <div className="border border-red-200 bg-red-50 rounded-xl p-4">
             <h3 className="text-xl font-semibold text-center text-red-800 mb-4">Parkinson's Sample</h3>
            {/* FIX: Pass correct props to ResultsDisplay */}
            <ResultsDisplay 
              geminiResult={parkinsonsGeminiResult} 
              classificationResult={parkinsonsClassificationResult} 
              onReset={onBack} 
            />
        </div>
      </div>
       <div className="text-center mt-6">
         <button
            onClick={onBack}
            className="bg-brand-blue text-white font-bold py-2 px-6 rounded-lg hover:bg-brand-teal transition-colors"
          >
           Back to Live Analysis
          </button>
       </div>
    </div>
  );
};
