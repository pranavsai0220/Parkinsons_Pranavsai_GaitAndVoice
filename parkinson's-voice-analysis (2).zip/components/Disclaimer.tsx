
import React from 'react';

export const Disclaimer: React.FC = () => {
  return (
    <footer className="w-full bg-gray-100 p-4 mt-8 border-t border-gray-200">
      <div className="container mx-auto text-center text-xs text-gray-600 max-w-3xl">
        <p className="font-bold mb-1">
          <span role="img" aria-label="warning" className="mr-1">⚠️</span>
          Disclaimer
        </p>
        <p>
          This MVP is for educational and research purposes only and is not a medical diagnostic tool. 
          The analysis provided is based on an AI model and should not be used for self-diagnosis or to make any health decisions. 
          Always consult with a qualified healthcare professional for any medical concerns.
        </p>
      </div>
    </footer>
  );
};
