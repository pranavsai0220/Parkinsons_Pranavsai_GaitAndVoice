
import React from 'react';

export const ModelPerformance: React.FC = () => {
  return (
    <div className="w-full bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 animate-fade-in">
      <h3 className="text-lg font-semibold text-brand-blue mb-3 text-center">Model Performance Breakdown</h3>

      <div className="text-xs text-gray-600 space-y-4">
        <p>
          To ensure our model's accuracy is realistic and not just "memorizing" the data (a problem called overfitting), we used a rigorous testing method called{' '}
          <strong>Leave-One-Out Cross-Validation</strong>. For each of the 195 samples in the dataset, a prediction was made using a model trained on the other 194 samples. This simulates performance on new, unseen data.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white p-3 rounded-lg border">
                <p className="font-bold text-center text-brand-teal">Sensitivity (Recall)</p>
                <p className="text-2xl font-bold text-center text-brand-teal my-1">~94%</p>
                <p className="text-center">
                    This is crucial: it means the model correctly identifies 94% of cases with Parkinson's indicators, minimizing the chance of missing a potential issue (False Negatives).
                </p>
            </div>
            <div className="bg-white p-3 rounded-lg border">
                 <p className="font-bold text-center text-brand-dark-orange">Specificity</p>
                <p className="text-2xl font-bold text-center text-brand-dark-orange my-1">~79%</p>
                <p className="text-center">
                    The model correctly identifies 79% of healthy cases. This means there's a moderate chance of a false alarm (False Positive), which is an acceptable trade-off for a screening tool designed not to miss potential cases.
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};
