
import React, { useMemo, useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import type { AnalysisResult, ClassificationResult, FeatureChartData } from '../types';
import { ModelPerformance } from './ModelPerformance';

interface ResultsDisplayProps {
  geminiResult: AnalysisResult;
  classificationResult: ClassificationResult;
  onReset: () => void;
}

const normalRanges = {
  pitch_variability: { min: 2, max: 8, label: 'Pitch Variability (%)' },
  jitter: { min: 0.2, max: 1.0, label: 'Jitter (%)' },
  shimmer: { min: 1, max: 5, label: 'Shimmer (%)' },
  speech_rate: { min: 140, max: 180, label: 'Speech Rate (wpm)' },
};

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ geminiResult, classificationResult, onReset }) => {
  const [showPerformance, setShowPerformance] = useState(false);
  const isHealthy = classificationResult.prediction === 'Healthy';
  const predictionColor = isHealthy ? 'text-brand-teal' : 'text-brand-dark-orange';
  const predictionBg = isHealthy ? 'bg-green-50' : 'bg-orange-50';
  const predictionBorder = isHealthy ? 'border-green-200' : 'border-orange-200';

  const featureChartData: FeatureChartData[] = useMemo(() => [
    {
      name: 'Pitch Var.',
      userValue: geminiResult.feature_extracts.pitch_variability,
      typicalMin: normalRanges.pitch_variability.min,
      typicalMax: normalRanges.pitch_variability.max,
    },
    {
      name: 'Jitter',
      userValue: geminiResult.feature_extracts.jitter,
      typicalMin: normalRanges.jitter.min,
      typicalMax: normalRanges.jitter.max,
    },
    {
      name: 'Shimmer',
      userValue: geminiResult.feature_extracts.shimmer,
      typicalMin: normalRanges.shimmer.min,
      typicalMax: normalRanges.shimmer.max,
    },
    {
      name: 'Speech Rate',
      userValue: geminiResult.feature_extracts.speech_rate,
      typicalMin: normalRanges.speech_rate.min,
      typicalMax: normalRanges.speech_rate.max,
    }
  ], [geminiResult.feature_extracts]);

  return (
    <div className="flex flex-col items-center animate-fade-in">
      <h2 className="text-2xl font-bold text-brand-blue mb-4">Analysis Results</h2>
      
      <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className={`md:col-span-1 flex flex-col items-center justify-center ${predictionBg} border ${predictionBorder} rounded-lg p-4`}>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Prediction</h3>
          <p className={`text-3xl font-bold ${predictionColor} mb-2`}>{classificationResult.prediction}</p>
          <p className="text-sm text-gray-500">
             Based on the UCI Parkinson's Dataset
          </p>
           <div className="w-full bg-gray-200 rounded-full h-2.5 my-4">
              <div className="bg-brand-blue h-2.5 rounded-full" style={{ width: `${classificationResult.confidence}%` }}></div>
            </div>
            <p className="text-lg font-semibold text-brand-blue">{classificationResult.confidence}% Confidence</p>
        </div>

        <div className="md:col-span-1 bg-gray-50 rounded-lg p-4 text-center">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Model Accuracy</h3>
          <p className="text-3xl font-bold text-brand-blue mb-2">~90%</p>
           <p className="text-xs text-gray-500 leading-tight">
            Our classification model, when tested against the public dataset, demonstrates high accuracy in distinguishing between healthy and Parkinsonian voice samples.
          </p>
          <button onClick={() => setShowPerformance(!showPerformance)} className="text-xs text-brand-blue hover:underline mt-2">
            {showPerformance ? 'Hide' : 'View'} Performance Details
          </button>
        </div>
      </div>
      
      {showPerformance && <ModelPerformance />}

       <div className="w-full bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">AI-Powered Reasoning</h3>
          <p className="text-gray-600 text-sm leading-relaxed">
            {geminiResult.analysis_summary}
          </p>
        </div>
      
      <div className="w-full bg-gray-50 rounded-lg p-4 mb-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 text-center">Feature Comparison</h3>
         <p className="text-xs text-center text-gray-500 mb-4 -mt-2">Comparing your voice features against typical ranges.</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={featureChartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" tick={{fill: '#4A5568', fontSize: 12}} />
            <YAxis tick={{fill: '#4A5568', fontSize: 12}}/>
            <Tooltip
                contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '0.5rem',
                }}
                labelStyle={{ fontWeight: 'bold', color: '#005f73' }}
            />
            <Legend wrapperStyle={{fontSize: "14px"}}/>
            <Bar dataKey="typicalMin" stackId="a" fill="#94d2bd" name="Typical Min" />
            <Bar dataKey="typicalMax" stackId="a" fill="#0a9396" name="Typical Max" />
            <Bar dataKey="userValue" fill="#ee9b00" name="Your Value" barSize={20} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
       <button
          onClick={onReset}
          className="bg-brand-blue text-white font-bold py-2 px-6 rounded-lg hover:bg-brand-teal transition-colors"
        >
          Analyze Another Sample
        </button>
    </div>
  );
};
