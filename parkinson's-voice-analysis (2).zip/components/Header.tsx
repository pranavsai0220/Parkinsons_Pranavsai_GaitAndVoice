
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md w-full">
      <div className="container mx-auto px-4 py-4">
        <h1 className="text-2xl md:text-3xl font-bold text-brand-blue text-center">
          Parkinson’s Disease Early Detection MVP
        </h1>
      </div>
    </header>
  );
};
