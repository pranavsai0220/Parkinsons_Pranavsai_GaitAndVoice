
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { UploadIcon, MicIcon, StopCircleIcon, AnalyzeIcon, CheckCircleIcon, SparklesIcon } from './IconComponents';
import { generateReadingPrompt } from '../services/geminiService';

interface AudioInputProps {
  onAudioReady: (source: File | Blob) => void;
  onAnalyze: () => void;
  audioSource: File | Blob | null;
}

export const AudioInput: React.FC<AudioInputProps> = ({ onAudioReady, onAnalyze, audioSource }) => {
  const [inputType, setInputType] = useState<'record' | 'upload'>('record');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [readingPrompt, setReadingPrompt] = useState<string>("");
  const [isLoadingPrompt, setIsLoadingPrompt] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const fetchPrompt = async () => {
    setIsLoadingPrompt(true);
    const text = await generateReadingPrompt();
    setReadingPrompt(text);
    setIsLoadingPrompt(false);
  };

  useEffect(() => {
    if (inputType === 'record' && !readingPrompt) {
      fetchPrompt();
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [inputType, readingPrompt]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      
      recorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        onAudioReady(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Could not access microphone. Please ensure you have given permission in your browser settings.");
    }
  };

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  }, []);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onAudioReady(file);
    }
  };
  
  const getAudioSourceName = () => {
    if (!audioSource) return "";
    if (audioSource instanceof File) return audioSource.name;
    return "recording.wav";
  }

  return (
    <div className="flex flex-col items-center">
      <h2 className="text-xl font-semibold text-gray-700 mb-4">Provide a Voice Sample</h2>
      
      <div className="flex border border-gray-300 rounded-lg p-1 bg-gray-100 mb-6">
        <button
          onClick={() => setInputType('record')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${inputType === 'record' ? 'bg-brand-blue text-white shadow' : 'text-gray-600 hover:bg-gray-200'}`}
        >
          <MicIcon className="inline-block mr-2 h-5 w-5"/> Record
        </button>
        <button
          onClick={() => setInputType('upload')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${inputType === 'upload' ? 'bg-brand-blue text-white shadow' : 'text-gray-600 hover:bg-gray-200'}`}
        >
          <UploadIcon className="inline-block mr-2 h-5 w-5"/> Upload
        </button>
      </div>

      <div className="w-full">
        {inputType === 'record' && (
          <div className="flex flex-col items-center">
            {/* Reading Prompt Section */}
            <div className="w-full bg-brand-bg rounded-lg p-6 mb-6 border-l-4 border-brand-teal shadow-inner relative">
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-sm font-bold uppercase tracking-wider text-brand-blue flex items-center">
                   <SparklesIcon className="h-4 w-4 mr-2" /> AI-Generated Reading Prompt
                </h3>
                <button 
                  onClick={fetchPrompt} 
                  disabled={isLoadingPrompt || isRecording}
                  className="text-xs text-brand-teal hover:underline disabled:opacity-50"
                >
                  Regenerate
                </button>
              </div>
              
              <div className="text-gray-400 text-[10px] mb-3 leading-tight italic uppercase tracking-widest font-bold">
                Note: Read at your regular pace, pitch, and voice. You do not have to finish the whole prompt within 20 seconds.
              </div>

              {isLoadingPrompt ? (
                <div className="h-32 flex items-center justify-center">
                   <div className="animate-pulse text-brand-light-teal">Generating passage...</div>
                </div>
              ) : (
                <div className="text-gray-700 leading-relaxed text-sm md:text-base font-serif max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                  {readingPrompt}
                </div>
              )}
            </div>

            {!isRecording ? (
              <button
                onClick={startRecording}
                className="bg-brand-red text-white font-bold py-3 px-6 rounded-full hover:bg-brand-dark-red transition-all transform hover:scale-105 flex items-center"
              >
                <MicIcon className="h-6 w-6 mr-2" />
                Start Recording
              </button>
            ) : (
              <div className="flex flex-col items-center">
                <button
                  onClick={stopRecording}
                  className="bg-gray-700 text-white font-bold py-3 px-6 rounded-full hover:bg-gray-900 transition-all flex items-center shadow-lg"
                >
                  <StopCircleIcon className="h-6 w-6 mr-2" />
                  Stop Recording
                </button>
                <div className="mt-4 text-lg font-mono text-brand-blue flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded-full mr-2 animate-pulse"></div>
                  {new Date(recordingTime * 1000).toISOString().substr(14, 5)}
                </div>
              </div>
            )}
          </div>
        )}
        {inputType === 'upload' && (
          <div className="w-full flex flex-col items-center">
             <p className="text-center text-gray-500 mb-6 text-sm">Upload an existing audio file (.wav, .mp3) of clear speech.</p>
            <label className="cursor-pointer bg-brand-light-teal text-brand-blue font-bold py-3 px-6 rounded-lg hover:bg-brand-teal hover:text-white transition-colors flex items-center">
              <UploadIcon className="h-6 w-6 mr-2"/>
              Choose Audio File
              <input type="file" accept="audio/wav,audio/mp3,audio/mpeg" className="hidden" onChange={handleFileUpload} />
            </label>
          </div>
        )}
      </div>

      {audioSource && (
        <div className="mt-8 text-center w-full">
           <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg flex items-center justify-center">
            <CheckCircleIcon className="h-6 w-6 mr-3 text-green-500"/>
            <span className="font-semibold truncate">Sample Loaded: {getAudioSourceName()}</span>
           </div>
          <button
            onClick={onAnalyze}
            className="mt-6 bg-brand-orange text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-brand-dark-orange transition-all shadow-xl flex items-center mx-auto transform hover:-translate-y-1"
          >
            <AnalyzeIcon className="h-6 w-6 mr-2"/>
            Analyze My Voice
          </button>
        </div>
      )}
    </div>
  );
};
