
import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY is not set. API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const prompt = `
You are an expert bio-acoustic analyst AI specializing in detecting vocal biomarkers for neurological conditions from audio data. Your analysis is for research and screening purposes only and is NOT a medical diagnosis.

Analyze the provided audio file for vocal patterns often associated with early-stage Parkinson's Disease. From the audio, you must extract the following specific acoustic features:
1.  **pitch_variability**: The variation in vocal pitch, as a percentage.
2.  **jitter**: The cycle-to-cycle variation in vocal frequency, as a percentage.
3.  **shimmer**: The cycle-to-cycle variation in vocal amplitude, as a percentage.
4.  **speech_rate**: The number of words spoken per minute.

CRITICAL INSTRUCTIONS:
- ONLY analyze the voice data provided. 
- DO NOT mention non-vocal symptoms such as limb tremors, gait, or general bradykinesia (slowness of physical movement).
- If you notice patterns related to vocal slowness or reduced intensity, describe them strictly as "reduced speech rate" or "diminished vocal range."
- Focus your 'analysis_summary' solely on how the acoustic features (jitter, shimmer, pitch, rate) contributed to the 'risk_score'.
- Use cautious and non-diagnostic language, such as 'patterns consistent with' or 'indicators suggest'.

Your entire response MUST be a single, valid JSON object with NO MARKDOWN formatting or any text outside of the JSON. The JSON object must strictly conform to the specified structure.
`;

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    risk_score: { type: Type.NUMBER, description: "A risk score from 0 to 100 based strictly on vocal indicators." },
    analysis_summary: { type: Type.STRING, description: "A brief summary of the vocal analysis (2-3 sentences). Focus only on voice." },
    feature_extracts: {
      type: Type.OBJECT,
      properties: {
        pitch_variability: { type: Type.NUMBER, description: "Pitch variability as a percentage." },
        jitter: { type: Type.NUMBER, description: "Jitter as a percentage." },
        shimmer: { type: Type.NUMBER, description: "Shimmer as a percentage." },
        speech_rate: { type: Type.NUMBER, description: "Speech rate in words per minute." },
      },
      required: ["pitch_variability", "jitter", "shimmer", "speech_rate"]
    },
  },
  required: ["risk_score", "analysis_summary", "feature_extracts"],
};

export const generateReadingPrompt = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a long, descriptive, and engaging reading passage (about 250 words) for a person to read aloud for voice quality testing. The theme should be nature, science, or a calm narrative. The language should be clear but varied in phonetic structure.",
    });
    return response.text || "The North Wind and the Sun were disputing which was the stronger, when a traveler came along wrapped in a warm cloak. They agreed that the one who first succeeded in making the traveler take his cloak off should be considered stronger than the other. Then the North Wind blew as hard as he could, but the more he blew the more closely did the traveler fold his cloak around him; and at last the North Wind gave up the attempt. Then the Sun shined out warmly, and immediately the traveler took off his cloak. And so the North Wind was obliged to confess that the Sun was the stronger of the two.";
  } catch (err) {
    console.error("Failed to generate prompt:", err);
    return "The North Wind and the Sun were disputing which was the stronger, when a traveler came along wrapped in a warm cloak. They agreed that the one who first succeeded in making the traveler take his cloak off should be considered stronger than the other. Then the North Wind blew as hard as he could, but the more he blew the more closely did the traveler fold his cloak around him; and at last the North Wind gave up the attempt. Then the Sun shined out warmly, and immediately the traveler took off his cloak. And so the North Wind was obliged to confess that the Sun was the stronger of the two.";
  }
};

export const analyzeVoice = async (audioBase64: string, mimeType: string): Promise<AnalysisResult> => {
  try {
    const audioPart = {
      inlineData: {
        data: audioBase64,
        mimeType,
      },
    };

    const textPart = {
      text: prompt,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", 
      contents: { parts: [audioPart, textPart] },
      config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema,
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("API returned an empty response.");
    }

    const parsedResult = JSON.parse(responseText);
    
    if (typeof parsedResult.risk_score !== 'number' || !parsedResult.analysis_summary || !parsedResult.feature_extracts) {
        throw new Error("Invalid JSON structure received from API.");
    }

    return parsedResult as AnalysisResult;
    
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error && error.message.includes('API key')) {
      throw new Error("Invalid API Key. Please check your configuration.");
    }
    throw new Error("Failed to analyze voice data. The AI model may be temporarily unavailable.");
  }
};
